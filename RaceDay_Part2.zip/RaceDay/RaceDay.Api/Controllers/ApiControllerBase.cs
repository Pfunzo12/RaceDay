using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;

namespace RaceDay.Api.Controllers;

/// <summary>Shared helpers for reading the logged-in user from the JWT.</summary>
[ApiController]
public abstract class ApiControllerBase : ControllerBase
{
    protected readonly RaceDayDbContext Db;

    protected ApiControllerBase(RaceDayDbContext db) => Db = db;

    /// <summary>The UserId stored in the token's "sub" claim.</summary>
    protected int CurrentUserId => int.TryParse(User.FindFirst("sub")?.Value, out var id) ? id : 0;

    protected Task<int?> CurrentOrganiserIdAsync() =>
        Db.Organisers.Where(o => o.UserId == CurrentUserId).Select(o => (int?)o.OrganiserId).FirstOrDefaultAsync();

    protected Task<int?> CurrentParticipantIdAsync() =>
        Db.Participants.Where(p => p.UserId == CurrentUserId).Select(p => (int?)p.ParticipantId).FirstOrDefaultAsync();

    protected static DateOnly Today => DateOnly.FromDateTime(DateTime.UtcNow);

    protected ObjectResult Fail(int status, string title, string? detail = null) =>
        Problem(title: title, detail: detail, statusCode: status);
}
