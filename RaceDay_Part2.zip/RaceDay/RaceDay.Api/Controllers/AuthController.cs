using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Registration and login.</summary>
[Produces("application/json")]
public class AuthController : ApiControllerBase
{
    private static readonly string[] Genders = { "Male", "Female", "Other" };
    private readonly ITokenService _tokens;

    public AuthController(RaceDayDbContext db, ITokenService tokens) : base(db) => _tokens = tokens;

    /// <summary>Registers a new Organiser or Participant account.</summary>
    /// <remarks>
    /// Organisers must supply <c>organisationName</c> and <c>contactNumber</c>.
    /// Participants must supply <c>dateOfBirth</c>, <c>gender</c> (Male/Female/Other), <c>emergencyContact</c> and <c>emergencyPhone</c>.
    /// The password is hashed with BCrypt before it is stored; the plain password is never saved.
    /// </remarks>
    /// <response code="201">Account created.</response>
    /// <response code="400">Validation failed (missing role-specific details, invalid role, weak password).</response>
    /// <response code="409">Email address is already registered.</response>
    [HttpPost("api/auth/register")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(RegisterResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        var role = Roles.Organiser.Equals(request.Role?.Trim(), StringComparison.OrdinalIgnoreCase) ? Roles.Organiser
                 : Roles.Participant.Equals(request.Role?.Trim(), StringComparison.OrdinalIgnoreCase) ? Roles.Participant
                 : null;

        if (role is null)
            ModelState.AddModelError(nameof(request.Role), "Role must be 'Organiser' or 'Participant'.");
        else if (role == Roles.Organiser)
        {
            if (string.IsNullOrWhiteSpace(request.OrganisationName))
                ModelState.AddModelError(nameof(request.OrganisationName), "OrganisationName is required for Organisers.");
            if (string.IsNullOrWhiteSpace(request.ContactNumber))
                ModelState.AddModelError(nameof(request.ContactNumber), "ContactNumber is required for Organisers.");
        }
        else
        {
            if (request.DateOfBirth is null || request.DateOfBirth >= Today)
                ModelState.AddModelError(nameof(request.DateOfBirth), "A valid DateOfBirth in the past is required for Participants.");
            if (request.Gender is null || !Genders.Contains(request.Gender))
                ModelState.AddModelError(nameof(request.Gender), "Gender must be Male, Female or Other.");
            if (string.IsNullOrWhiteSpace(request.EmergencyContact))
                ModelState.AddModelError(nameof(request.EmergencyContact), "EmergencyContact is required for Participants.");
            if (string.IsNullOrWhiteSpace(request.EmergencyPhone))
                ModelState.AddModelError(nameof(request.EmergencyPhone), "EmergencyPhone is required for Participants.");
        }

        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var email = request.Email.Trim().ToLowerInvariant();
        if (await Db.Users.AnyAsync(u => u.Email == email))
            return Fail(StatusCodes.Status409Conflict, "Email already registered.");

        var user = new User
        {
            Email = email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            FirstName = request.FirstName.Trim(),
            LastName = request.LastName.Trim(),
            Role = role!
        };

        if (role == Roles.Organiser)
        {
            user.Organiser = new Organiser
            {
                OrganisationName = request.OrganisationName!.Trim(),
                ContactNumber = request.ContactNumber!.Trim(),
                Website = request.Website?.Trim()
            };
        }
        else
        {
            user.Participant = new Participant
            {
                DateOfBirth = request.DateOfBirth!.Value,
                Gender = request.Gender!,
                Province = request.Province?.Trim(),
                ClubName = request.ClubName?.Trim(),
                EmergencyContact = request.EmergencyContact!.Trim(),
                EmergencyPhone = request.EmergencyPhone!.Trim()
            };
        }

        Db.Users.Add(user);
        await Db.SaveChangesAsync();

        return Created("api/users/me", new RegisterResponse
        {
            UserId = user.UserId,
            Email = user.Email,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Role = user.Role
        });
    }

    /// <summary>Logs in and returns a JWT bearer token.</summary>
    /// <remarks>
    /// The token carries the user's id and role and is the "session" for all later requests:
    /// click <b>Authorize</b> in Swagger and paste the token (without the word "Bearer").
    /// </remarks>
    /// <response code="200">Login successful; token returned.</response>
    /// <response code="401">Email or password is incorrect.</response>
    [HttpPost("api/auth/login")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(AuthResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await Db.Users.FirstOrDefaultAsync(u => u.Email == email);

        if (user is null || !PasswordMatches(request.Password, user.PasswordHash))
            return Fail(StatusCodes.Status401Unauthorized, "Invalid email or password.");

        var (token, expires) = _tokens.CreateToken(user);
        return Ok(new AuthResponse { Token = token, Role = user.Role, UserId = user.UserId, ExpiresAt = expires });
    }

    private static bool PasswordMatches(string password, string hash)
    {
        try { return BCrypt.Net.BCrypt.Verify(password, hash); }
        catch (Exception) { return false; } // e.g. malformed/placeholder hash
    }
}
