using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Age/distance categories for an event (e.g. Under 20, Senior, 10km, 21km).</summary>
[Produces("application/json")]
public class CategoriesController : ApiControllerBase
{
    public CategoriesController(RaceDayDbContext db) : base(db) { }

    /// <summary>Lists the categories offered at an event, with remaining spots.</summary>
    /// <response code="200">Categories ordered by distance.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("api/events/{eventId:int}/categories")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<CategoryResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetForEvent(int eventId)
    {
        if (!await Db.Events.AnyAsync(e => e.EventId == eventId)) return NotFound();
        var categories = await Db.Categories.Where(c => c.EventId == eventId)
            .OrderBy(c => c.DistanceKm).ThenBy(c => c.Name)
            .Select(Projections.CategoryInfo).ToListAsync();
        return Ok(categories);
    }

    /// <summary>Returns one category with its remaining capacity.</summary>
    /// <response code="200">The category.</response>
    /// <response code="404">Category not found.</response>
    [HttpGet("api/categories/{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCategory(int id)
    {
        var category = await Db.Categories.Where(c => c.CategoryId == id).Select(Projections.CategoryInfo).FirstOrDefaultAsync();
        return category is null ? NotFound() : Ok(category);
    }

    /// <summary>Adds a category to an event the logged-in Organiser owns.</summary>
    /// <response code="201">Category created.</response>
    /// <response code="400">Validation failed (e.g. MaxAge below MinAge).</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event not found.</response>
    /// <response code="409">A category with this name already exists for the event.</response>
    [HttpPost("api/events/{eventId:int}/categories")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Create(int eventId, [FromBody] CategoryRequest request)
    {
        Validate(request);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var ev = await Db.Events.FindAsync(eventId);
        if (ev is null) return NotFound();
        if (ev.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        var name = request.Name.Trim();
        if (await Db.Categories.AnyAsync(c => c.EventId == eventId && c.Name == name))
            return Fail(StatusCodes.Status409Conflict, "A category with this name already exists for this event.");

        var category = new Category { EventId = eventId };
        Apply(category, request);
        Db.Categories.Add(category);
        await Db.SaveChangesAsync();

        var response = await Db.Categories.Where(c => c.CategoryId == category.CategoryId).Select(Projections.CategoryInfo).FirstAsync();
        return CreatedAtAction(nameof(GetCategory), new { id = category.CategoryId }, response);
    }

    /// <summary>Updates a category on an event the logged-in Organiser owns.</summary>
    /// <response code="200">Updated category.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Category not found.</response>
    /// <response code="409">Another category on this event already uses that name.</response>
    [HttpPut("api/categories/{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Update(int id, [FromBody] CategoryRequest request)
    {
        Validate(request);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var category = await Db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryId == id);
        if (category is null) return NotFound();
        if (category.Event.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        var name = request.Name.Trim();
        if (await Db.Categories.AnyAsync(c => c.EventId == category.EventId && c.Name == name && c.CategoryId != id))
            return Fail(StatusCodes.Status409Conflict, "A category with this name already exists for this event.");

        Apply(category, request);
        await Db.SaveChangesAsync();
        return Ok(await Db.Categories.Where(c => c.CategoryId == id).Select(Projections.CategoryInfo).FirstAsync());
    }

    /// <summary>Deletes a category on an event the logged-in Organiser owns.</summary>
    /// <response code="204">Category deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Category not found.</response>
    /// <response code="409">The category already has enrolments.</response>
    [HttpDelete("api/categories/{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var category = await Db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryId == id);
        if (category is null) return NotFound();
        if (category.Event.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        if (await Db.Enrolments.AnyAsync(e => e.CategoryId == id))
            return Fail(StatusCodes.Status409Conflict, "Category has enrolments and cannot be deleted.");

        Db.Categories.Remove(category);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    private void Validate(CategoryRequest r)
    {
        if (r.MaxAge is not null && r.MaxAge < r.MinAge)
            ModelState.AddModelError(nameof(r.MaxAge), "MaxAge cannot be less than MinAge.");
    }

    private static void Apply(Category c, CategoryRequest r)
    {
        c.Name = r.Name.Trim();
        c.DistanceKm = r.DistanceKm;
        c.MinAge = r.MinAge;
        c.MaxAge = r.MaxAge;
        c.EntryFee = r.EntryFee;
        c.MaxParticipants = r.MaxParticipants;
    }
}
