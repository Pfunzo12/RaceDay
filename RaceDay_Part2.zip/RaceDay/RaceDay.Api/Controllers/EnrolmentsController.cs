using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Participants enter events by choosing a category; Organisers view entries for their events.</summary>
[Produces("application/json")]
public class EnrolmentsController : ApiControllerBase
{
    public EnrolmentsController(RaceDayDbContext db) : base(db) { }

    /// <summary>Enrols the logged-in Participant in a category (and therefore its event).</summary>
    /// <remarks>
    /// Records the link between the Participant, the category and its event, and assigns the next free race number for the event.
    /// A Participant may only hold one active enrolment per event. Age limits, capacity, event status and the registration deadline are checked.
    /// </remarks>
    /// <response code="201">Enrolled; the enrolment (with race number) is returned.</response>
    /// <response code="400">Event not open, deadline passed, or age outside the category limits.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Participants may enrol.</response>
    /// <response code="404">Category not found.</response>
    /// <response code="409">Already enrolled in this event, or the category is full.</response>
    [HttpPost("api/categories/{categoryId:int}/enrolments")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(EnrolmentResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Enrol(int categoryId)
    {
        var category = await Db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryId == categoryId);
        if (category is null) return NotFound();

        var participant = await Db.Participants.FirstOrDefaultAsync(p => p.UserId == CurrentUserId);
        if (participant is null) return Forbid();

        var ev = category.Event;
        if (ev.Status != "Open")
            return Fail(StatusCodes.Status400BadRequest, "This event is not open for enrolment.");
        if (Today > ev.RegistrationDeadline)
            return Fail(StatusCodes.Status400BadRequest, "The registration deadline has passed.");

        var age = AgeOn(participant.DateOfBirth, ev.EventDate);
        if (age < category.MinAge || (category.MaxAge is not null && age > category.MaxAge))
            return Fail(StatusCodes.Status400BadRequest, "You do not meet the age requirements for this category.");

        var existing = await Db.Enrolments
            .Where(e => e.ParticipantId == participant.ParticipantId && e.Category.EventId == ev.EventId)
            .ToListAsync();
        if (existing.Any(e => e.Status == "Confirmed"))
            return Fail(StatusCodes.Status409Conflict, "You are already enrolled in this event.");

        var confirmed = await Db.Enrolments.CountAsync(e => e.CategoryId == categoryId && e.Status == "Confirmed");
        if (confirmed >= category.MaxParticipants)
            return Fail(StatusCodes.Status409Conflict, "This category is full.");

        var maxRace = await Db.Enrolments.Where(e => e.Category.EventId == ev.EventId).MaxAsync(e => e.RaceNumber);
        var raceNumber = (maxRace ?? 0) + 1;

        // A previously cancelled enrolment for this category is re-activated (unique participant+category).
        var enrolment = existing.FirstOrDefault(e => e.CategoryId == categoryId);
        if (enrolment is null)
        {
            enrolment = new Enrolment { ParticipantId = participant.ParticipantId, CategoryId = categoryId };
            Db.Enrolments.Add(enrolment);
        }
        enrolment.Status = "Confirmed";
        enrolment.PaymentStatus = "Pending";
        enrolment.EnrolmentDate = DateTime.UtcNow;
        enrolment.RaceNumber = raceNumber;
        await Db.SaveChangesAsync();

        var response = await Db.Enrolments.Where(e => e.EnrolmentId == enrolment.EnrolmentId)
            .Select(Projections.EnrolmentInfo).FirstAsync();
        return CreatedAtAction(nameof(GetEnrolment), new { id = enrolment.EnrolmentId }, response);
    }

    /// <summary>Lists the logged-in Participant's own enrolments (upcoming and past).</summary>
    /// <response code="200">The enrolments, newest event first.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Participants may call this.</response>
    [HttpGet("api/enrolments/mine")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(List<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMine()
    {
        var list = await Db.Enrolments.Where(e => e.Participant.UserId == CurrentUserId)
            .OrderByDescending(e => e.Category.Event.EventDate)
            .Select(Projections.EnrolmentInfo).ToListAsync();
        return Ok(list);
    }

    /// <summary>Returns one enrolment. Visible to the Participant who owns it and to the Organiser of its event.</summary>
    /// <response code="200">The enrolment.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">The enrolment belongs to someone else's entry or event.</response>
    /// <response code="404">Enrolment not found.</response>
    [HttpGet("api/enrolments/{id:int}")]
    [Authorize]
    [ProducesResponseType(typeof(EnrolmentResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEnrolment(int id)
    {
        var access = await Db.Enrolments.Where(e => e.EnrolmentId == id)
            .Select(e => new { OwnerUserId = e.Participant.UserId, OrganiserUserId = e.Category.Event.Organiser.UserId })
            .FirstOrDefaultAsync();
        if (access is null) return NotFound();
        if (access.OwnerUserId != CurrentUserId && access.OrganiserUserId != CurrentUserId) return Forbid();

        return Ok(await Db.Enrolments.Where(e => e.EnrolmentId == id).Select(Projections.EnrolmentInfo).FirstAsync());
    }

    /// <summary>Cancels the logged-in Participant's enrolment.</summary>
    /// <response code="204">Enrolment cancelled.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not a Participant, or not your enrolment.</response>
    /// <response code="404">Enrolment not found.</response>
    /// <response code="409">The event has already taken place.</response>
    [HttpDelete("api/enrolments/{id:int}")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Cancel(int id)
    {
        var enrolment = await Db.Enrolments.Include(e => e.Participant).Include(e => e.Category).ThenInclude(c => c.Event)
            .FirstOrDefaultAsync(e => e.EnrolmentId == id);
        if (enrolment is null) return NotFound();
        if (enrolment.Participant.UserId != CurrentUserId) return Forbid();

        if (enrolment.Category.Event.Status == "Completed" || enrolment.Category.Event.EventDate < Today)
            return Fail(StatusCodes.Status409Conflict, "The event has already taken place.");

        enrolment.Status = "Cancelled";
        await Db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Lists all enrolments (the entry list) for an event the logged-in Organiser owns.</summary>
    /// <response code="200">Enrolments, ordered by race number.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("api/events/{eventId:int}/enrolments")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(List<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetForEvent(int eventId)
    {
        var ev = await Db.Events.FindAsync(eventId);
        if (ev is null) return NotFound();
        if (ev.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        var list = await Db.Enrolments.Where(e => e.Category.EventId == eventId)
            .OrderBy(e => e.RaceNumber)
            .Select(Projections.EnrolmentInfo).ToListAsync();
        return Ok(list);
    }

    /// <summary>Updates the payment status of an enrolment for an event the Organiser owns.</summary>
    /// <response code="200">Updated enrolment.</response>
    /// <response code="400">Invalid payment status.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Enrolment not found.</response>
    [HttpPatch("api/enrolments/{id:int}/payment")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EnrolmentResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdatePayment(int id, [FromBody] PaymentUpdateRequest request)
    {
        var enrolment = await Db.Enrolments.Include(e => e.Category).ThenInclude(c => c.Event)
            .FirstOrDefaultAsync(e => e.EnrolmentId == id);
        if (enrolment is null) return NotFound();
        if (enrolment.Category.Event.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        enrolment.PaymentStatus = request.PaymentStatus;
        await Db.SaveChangesAsync();
        return Ok(await Db.Enrolments.Where(e => e.EnrolmentId == id).Select(Projections.EnrolmentInfo).FirstAsync());
    }

    private static int AgeOn(DateOnly dateOfBirth, DateOnly date)
    {
        var age = date.Year - dateOfBirth.Year;
        if (dateOfBirth > date.AddYears(-age)) age--;
        return age;
    }
}
