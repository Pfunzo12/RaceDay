using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Browse events (everyone) and manage events (Organisers).</summary>
[Produces("application/json")]
public class EventsController : ApiControllerBase
{
    private readonly IWeatherService _weather;

    public EventsController(RaceDayDbContext db, IWeatherService weather) : base(db) => _weather = weather;

    /// <summary>Lists upcoming events.</summary>
    /// <remarks>
    /// Optional filters: <c>type</c> (Running/Walking/Cycling), <c>province</c>, <c>from</c> and <c>to</c> (yyyy-MM-dd) and <c>search</c> (name contains).
    /// If <c>from</c> is omitted only events from today onward are returned.
    /// </remarks>
    /// <response code="200">A (possibly empty) list of events.</response>
    [HttpGet("api/events")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<EventSummaryResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetEvents([FromQuery] string? type, [FromQuery] string? province,
        [FromQuery(Name = "from")] DateOnly? fromDate, [FromQuery(Name = "to")] DateOnly? toDate, [FromQuery] string? search)
    {
        var query = Db.Events.AsQueryable();
        var start = fromDate ?? Today;
        query = query.Where(e => e.EventDate >= start);
        if (toDate is not null) query = query.Where(e => e.EventDate <= toDate);
        if (!string.IsNullOrWhiteSpace(type)) { var t = type.Trim().ToLower(); query = query.Where(e => e.EventType.ToLower() == t); }
        if (!string.IsNullOrWhiteSpace(province)) { var p = province.Trim().ToLower(); query = query.Where(e => e.Province.ToLower() == p); }
        if (!string.IsNullOrWhiteSpace(search)) { var s = search.Trim(); query = query.Where(e => e.Name.Contains(s)); }

        var events = await query.OrderBy(e => e.EventDate).ThenBy(e => e.StartTime)
            .Select(Projections.EventSummary).ToListAsync();
        return Ok(events);
    }

    /// <summary>Returns full details of one event, including its categories.</summary>
    /// <response code="200">The event.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("api/events/{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(EventDetailResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEvent(int id)
    {
        var detail = await LoadDetail(id);
        return detail is null ? NotFound() : Ok(detail);
    }

    /// <summary>Lists all events created by the logged-in Organiser (any date, any status).</summary>
    /// <response code="200">The Organiser's events.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Organisers may call this.</response>
    [HttpGet("api/events/mine")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(List<EventSummaryResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyEvents()
    {
        var events = await Db.Events.Where(e => e.Organiser.UserId == CurrentUserId)
            .OrderByDescending(e => e.EventDate)
            .Select(Projections.EventSummary).ToListAsync();
        return Ok(events);
    }

    /// <summary>Creates a new event owned by the logged-in Organiser.</summary>
    /// <remarks>Captures name, description, date, location (venue, city, province, coordinates) and event type (Running, Walking or Cycling). Distances are added as categories.</remarks>
    /// <response code="201">Event created.</response>
    /// <response code="400">Validation failed (e.g. registration deadline after the event date).</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Organisers may create events.</response>
    [HttpPost("api/events")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EventDetailResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> CreateEvent([FromBody] EventRequest request)
    {
        ValidateDates(request);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var organiserId = await CurrentOrganiserIdAsync();
        if (organiserId is null) return Forbid();

        var ev = new Event { OrganiserId = organiserId.Value, Status = request.Status ?? "Open" };
        Apply(ev, request);
        Db.Events.Add(ev);
        await Db.SaveChangesAsync();

        var detail = await LoadDetail(ev.EventId);
        return CreatedAtAction(nameof(GetEvent), new { id = ev.EventId }, detail);
    }

    /// <summary>Updates an event the logged-in Organiser owns.</summary>
    /// <response code="200">Updated event.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event not found.</response>
    [HttpPut("api/events/{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EventDetailResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateEvent(int id, [FromBody] EventRequest request)
    {
        ValidateDates(request);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var ev = await Db.Events.FindAsync(id);
        if (ev is null) return NotFound();
        if (ev.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        Apply(ev, request);
        if (request.Status is not null) ev.Status = request.Status;
        await Db.SaveChangesAsync();
        return Ok(await LoadDetail(id));
    }

    /// <summary>Deletes an event the logged-in Organiser owns (its categories and route are deleted too).</summary>
    /// <response code="204">Event deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event not found.</response>
    /// <response code="409">The event already has enrolments; cancel it instead (set Status to Cancelled).</response>
    [HttpDelete("api/events/{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var ev = await Db.Events.FindAsync(id);
        if (ev is null) return NotFound();
        if (ev.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        if (await Db.Enrolments.AnyAsync(e => e.Category.EventId == id))
            return Fail(StatusCodes.Status409Conflict, "Event has enrolments and cannot be deleted.",
                "Set the event Status to Cancelled instead.");

        Db.Events.Remove(ev);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Returns live weather for the event venue, plus the forecast for race day when available.</summary>
    /// <remarks>Data comes from the Open-Meteo API. Forecasts only exist for about 16 days ahead, so <c>eventDayForecast</c> may be null.</remarks>
    /// <response code="200">Current conditions and race-day forecast.</response>
    /// <response code="404">Event not found.</response>
    /// <response code="502">The external weather service is unavailable.</response>
    [HttpGet("api/events/{id:int}/weather")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(WeatherResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status502BadGateway)]
    public async Task<IActionResult> GetWeather(int id, CancellationToken ct)
    {
        var ev = await Db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.EventId == id, ct);
        if (ev is null) return NotFound();

        try
        {
            return Ok(await _weather.GetWeatherAsync(ev.Latitude, ev.Longitude, ev.EventDate, ct));
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or System.Text.Json.JsonException or KeyNotFoundException)
        {
            return Fail(StatusCodes.Status502BadGateway, "Weather service unavailable.", "Please try again later.");
        }
    }

    /// <summary>Returns the ordered route points of an event.</summary>
    /// <response code="200">Route points in order (empty list if none defined).</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("api/events/{id:int}/route")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<RoutePointDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetRoute(int id)
    {
        if (!await Db.Events.AnyAsync(e => e.EventId == id)) return NotFound();
        var points = await Db.RoutePoints.Where(r => r.EventId == id).OrderBy(r => r.SequenceNo)
            .Select(r => new RoutePointDto { SequenceNo = r.SequenceNo, Label = r.Label, Latitude = r.Latitude, Longitude = r.Longitude })
            .ToListAsync();
        return Ok(points);
    }

    /// <summary>Replaces the route points of an event the Organiser owns.</summary>
    /// <response code="200">The saved route.</response>
    /// <response code="400">Invalid points or duplicate sequence numbers.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event not found.</response>
    [HttpPut("api/events/{id:int}/route")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(List<RoutePointDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> SaveRoute(int id, [FromBody] RouteRequest request)
    {
        if (request.Points.Select(p => p.SequenceNo).Distinct().Count() != request.Points.Count)
            ModelState.AddModelError(nameof(request.Points), "SequenceNo values must be unique.");
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var ev = await Db.Events.FindAsync(id);
        if (ev is null) return NotFound();
        if (ev.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        var existing = await Db.RoutePoints.Where(r => r.EventId == id).ToListAsync();
        Db.RoutePoints.RemoveRange(existing);
        await Db.SaveChangesAsync(); // delete first so the (EventId, SequenceNo) unique index is never violated

        Db.RoutePoints.AddRange(request.Points.Select(p => new RoutePoint
        {
            EventId = id,
            SequenceNo = p.SequenceNo,
            Label = p.Label,
            Latitude = p.Latitude,
            Longitude = p.Longitude
        }));
        await Db.SaveChangesAsync();

        return Ok(request.Points.OrderBy(p => p.SequenceNo).ToList());
    }

    // ---------- helpers ----------

    private void ValidateDates(EventRequest r)
    {
        if (r.RegistrationDeadline > r.EventDate)
            ModelState.AddModelError(nameof(r.RegistrationDeadline), "RegistrationDeadline cannot be after EventDate.");
    }

    private static void Apply(Event ev, EventRequest r)
    {
        ev.Name = r.Name.Trim();
        ev.Description = r.Description?.Trim();
        ev.EventType = r.EventType;
        ev.EventDate = r.EventDate;
        ev.StartTime = r.StartTime;
        ev.Venue = r.Venue.Trim();
        ev.City = r.City.Trim();
        ev.Province = r.Province.Trim();
        ev.Latitude = r.Latitude;
        ev.Longitude = r.Longitude;
        ev.RegistrationDeadline = r.RegistrationDeadline;
    }

    private async Task<EventDetailResponse?> LoadDetail(int id)
    {
        var detail = await Db.Events.Where(e => e.EventId == id).Select(e => new EventDetailResponse
        {
            EventId = e.EventId,
            Name = e.Name,
            Description = e.Description,
            EventType = e.EventType,
            EventDate = e.EventDate,
            StartTime = e.StartTime,
            Venue = e.Venue,
            City = e.City,
            Province = e.Province,
            Latitude = e.Latitude,
            Longitude = e.Longitude,
            RegistrationDeadline = e.RegistrationDeadline,
            Status = e.Status,
            OrganiserId = e.OrganiserId,
            OrganiserName = e.Organiser.OrganisationName
        }).FirstOrDefaultAsync();

        if (detail is null) return null;

        detail.Categories = await Db.Categories.Where(c => c.EventId == id)
            .OrderBy(c => c.DistanceKm).Select(Projections.CategoryInfo).ToListAsync();
        detail.DistancesKm = detail.Categories.Select(c => c.DistanceKm).ToList();
        return detail;
    }
}
