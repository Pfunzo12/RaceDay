using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Finish times and positions: captured by Organisers, viewable by everyone (and by Participants for their own).</summary>
[Produces("application/json")]
public class ResultsController : ApiControllerBase
{
    public ResultsController(RaceDayDbContext db) : base(db) { }

    /// <summary>Returns the results of an event, grouped by category and ordered by position.</summary>
    /// <response code="200">Results per category.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("api/events/{eventId:int}/results")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(EventResultsResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetForEvent(int eventId)
    {
        var ev = await Db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.EventId == eventId);
        if (ev is null) return NotFound();

        var categories = await Db.Categories.Where(c => c.EventId == eventId)
            .OrderBy(c => c.DistanceKm).ThenBy(c => c.Name)
            .Select(c => new { c.CategoryId, c.Name, c.DistanceKm }).ToListAsync();
        var results = await Db.Results.Where(r => r.Enrolment.Category.EventId == eventId)
            .Select(Projections.ResultInfo).ToListAsync();

        return Ok(new EventResultsResponse
        {
            EventId = ev.EventId,
            EventName = ev.Name,
            Categories = categories.Select(c => new CategoryResultsResponse
            {
                CategoryId = c.CategoryId,
                CategoryName = c.Name,
                DistanceKm = c.DistanceKm,
                Results = Ordered(results.Where(r => r.CategoryId == c.CategoryId))
            }).ToList()
        });
    }

    /// <summary>Returns the results of a single category, ordered by position.</summary>
    /// <response code="200">Results for the category.</response>
    /// <response code="404">Category not found.</response>
    [HttpGet("api/categories/{categoryId:int}/results")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetForCategory(int categoryId)
    {
        if (!await Db.Categories.AnyAsync(c => c.CategoryId == categoryId)) return NotFound();
        var results = await Db.Results.Where(r => r.Enrolment.CategoryId == categoryId)
            .Select(Projections.ResultInfo).ToListAsync();
        return Ok(Ordered(results));
    }

    /// <summary>Returns the logged-in Participant's own results.</summary>
    /// <response code="200">The Participant's results, newest event first.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Participants may call this.</response>
    [HttpGet("api/results/mine")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(List<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMine()
    {
        var results = await Db.Results.Where(r => r.Enrolment.Participant.UserId == CurrentUserId)
            .OrderByDescending(r => r.Enrolment.Category.Event.EventDate)
            .Select(Projections.ResultInfo).ToListAsync();
        return Ok(results);
    }

    /// <summary>Captures the finish time and position for an enrolled Participant.</summary>
    /// <remarks>Only allowed once the event date has arrived. A "Finished" result must include a finishTime. Positions must be unique within a category.</remarks>
    /// <response code="201">Result captured.</response>
    /// <response code="400">Invalid data, enrolment cancelled, or the event has not taken place yet.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Enrolment not found.</response>
    /// <response code="409">A result already exists for this enrolment, or the position is taken.</response>
    [HttpPost("api/enrolments/{enrolmentId:int}/result")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(ResultResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Create(int enrolmentId, [FromBody] ResultRequest request)
    {
        Validate(request);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var enrolment = await Db.Enrolments.Include(e => e.Category).ThenInclude(c => c.Event)
            .FirstOrDefaultAsync(e => e.EnrolmentId == enrolmentId);
        if (enrolment is null) return NotFound();
        if (enrolment.Category.Event.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        if (enrolment.Status != "Confirmed")
            return Fail(StatusCodes.Status400BadRequest, "Results cannot be captured for a cancelled enrolment.");
        if (enrolment.Category.Event.EventDate > Today)
            return Fail(StatusCodes.Status400BadRequest, "Results can only be captured once the event has taken place.");
        if (await Db.Results.AnyAsync(r => r.EnrolmentId == enrolmentId))
            return Fail(StatusCodes.Status409Conflict, "A result already exists for this enrolment.");
        if (await PositionTaken(enrolment.CategoryId, request.Position, null))
            return Fail(StatusCodes.Status409Conflict, "That position is already taken in this category.");

        var result = new Result
        {
            EnrolmentId = enrolmentId,
            FinishTime = request.FinishTime,
            Position = request.Position,
            ResultStatus = request.ResultStatus
        };
        Db.Results.Add(result);
        await Db.SaveChangesAsync();

        var response = await Db.Results.Where(r => r.ResultId == result.ResultId).Select(Projections.ResultInfo).FirstAsync();
        return Created($"api/results/{result.ResultId}", response);
    }

    /// <summary>Corrects an existing result.</summary>
    /// <response code="200">Updated result.</response>
    /// <response code="400">Invalid data.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Result not found.</response>
    /// <response code="409">The position is already taken in this category.</response>
    [HttpPut("api/results/{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(ResultResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Update(int id, [FromBody] ResultRequest request)
    {
        Validate(request);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var result = await Db.Results.Include(r => r.Enrolment).ThenInclude(e => e.Category).ThenInclude(c => c.Event)
            .FirstOrDefaultAsync(r => r.ResultId == id);
        if (result is null) return NotFound();
        if (result.Enrolment.Category.Event.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        if (await PositionTaken(result.Enrolment.CategoryId, request.Position, id))
            return Fail(StatusCodes.Status409Conflict, "That position is already taken in this category.");

        result.FinishTime = request.FinishTime;
        result.Position = request.Position;
        result.ResultStatus = request.ResultStatus;
        await Db.SaveChangesAsync();

        return Ok(await Db.Results.Where(r => r.ResultId == id).Select(Projections.ResultInfo).FirstAsync());
    }

    /// <summary>Deletes a result.</summary>
    /// <response code="204">Result deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Result not found.</response>
    [HttpDelete("api/results/{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await Db.Results.Include(r => r.Enrolment).ThenInclude(e => e.Category).ThenInclude(c => c.Event)
            .FirstOrDefaultAsync(r => r.ResultId == id);
        if (result is null) return NotFound();
        if (result.Enrolment.Category.Event.OrganiserId != await CurrentOrganiserIdAsync()) return Forbid();

        Db.Results.Remove(result);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    private void Validate(ResultRequest r)
    {
        if (r.ResultStatus == "Finished" && r.FinishTime is null)
            ModelState.AddModelError(nameof(r.FinishTime), "FinishTime is required when ResultStatus is Finished.");
        if (r.FinishTime is not null && r.FinishTime <= TimeSpan.Zero)
            ModelState.AddModelError(nameof(r.FinishTime), "FinishTime must be greater than zero.");
        if (r.ResultStatus != "Finished" && r.Position is not null)
            ModelState.AddModelError(nameof(r.Position), "Only finishers can have a position.");
    }

    private Task<bool> PositionTaken(int categoryId, int? position, int? excludeResultId) =>
        position is null
            ? Task.FromResult(false)
            : Db.Results.AnyAsync(r => r.Enrolment.CategoryId == categoryId && r.Position == position && r.ResultId != excludeResultId);

    private static List<ResultResponse> Ordered(IEnumerable<ResultResponse> results) =>
        results.OrderBy(r => r.Position ?? int.MaxValue).ThenBy(r => r.FinishTime ?? TimeSpan.MaxValue).ToList();
}
