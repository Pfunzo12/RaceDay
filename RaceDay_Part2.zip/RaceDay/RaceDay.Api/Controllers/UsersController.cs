using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>View and manage the logged-in user's own profile.</summary>
[Authorize]
[Produces("application/json")]
public class UsersController : ApiControllerBase
{
    private static readonly string[] Genders = { "Male", "Female", "Other" };

    public UsersController(RaceDayDbContext db) : base(db) { }

    /// <summary>Returns the logged-in user's profile.</summary>
    /// <response code="200">The profile, including Organiser or Participant details.</response>
    /// <response code="401">Not logged in.</response>
    [HttpGet("api/users/me")]
    [ProducesResponseType(typeof(UserProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetMe()
    {
        var user = await LoadUser();
        return user is null ? Unauthorized() : Ok(ToProfile(user));
    }

    /// <summary>Updates the logged-in user's profile.</summary>
    /// <remarks>Organisers may change organisation fields; Participants may change gender, province, club and emergency contact. Email and role cannot be changed.</remarks>
    /// <response code="200">The updated profile.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    [HttpPut("api/users/me")]
    [ProducesResponseType(typeof(UserProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UpdateMe([FromBody] UpdateProfileRequest request)
    {
        var user = await LoadUser();
        if (user is null) return Unauthorized();

        if (user.Participant is not null && request.Gender is not null && !Genders.Contains(request.Gender))
            ModelState.AddModelError(nameof(request.Gender), "Gender must be Male, Female or Other.");
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        user.FirstName = request.FirstName.Trim();
        user.LastName = request.LastName.Trim();

        if (user.Organiser is { } org)
        {
            if (!string.IsNullOrWhiteSpace(request.OrganisationName)) org.OrganisationName = request.OrganisationName.Trim();
            if (!string.IsNullOrWhiteSpace(request.ContactNumber)) org.ContactNumber = request.ContactNumber.Trim();
            if (request.Website is not null) org.Website = request.Website.Trim();
        }
        else if (user.Participant is { } p)
        {
            if (request.Gender is not null) p.Gender = request.Gender;
            if (request.Province is not null) p.Province = request.Province.Trim();
            if (request.ClubName is not null) p.ClubName = request.ClubName.Trim();
            if (!string.IsNullOrWhiteSpace(request.EmergencyContact)) p.EmergencyContact = request.EmergencyContact.Trim();
            if (!string.IsNullOrWhiteSpace(request.EmergencyPhone)) p.EmergencyPhone = request.EmergencyPhone.Trim();
        }

        await Db.SaveChangesAsync();
        return Ok(ToProfile(user));
    }

    /// <summary>Changes the logged-in user's password.</summary>
    /// <response code="204">Password changed.</response>
    /// <response code="400">New password does not meet requirements.</response>
    /// <response code="401">Not logged in, or the current password is wrong.</response>
    [HttpPut("api/users/me/password")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest request)
    {
        var user = await Db.Users.FindAsync(CurrentUserId);
        if (user is null) return Unauthorized();

        bool valid;
        try { valid = BCrypt.Net.BCrypt.Verify(request.CurrentPassword, user.PasswordHash); }
        catch (Exception) { valid = false; }
        if (!valid) return Fail(StatusCodes.Status401Unauthorized, "Current password is incorrect.");

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.NewPassword);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Deletes the logged-in user's account.</summary>
    /// <response code="204">Account deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="409">Organisers with events or Participants with enrolments cannot be deleted.</response>
    [HttpDelete("api/users/me")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteMe()
    {
        var user = await Db.Users.FindAsync(CurrentUserId);
        if (user is null) return Unauthorized();

        var hasEvents = await Db.Events.AnyAsync(e => e.Organiser.UserId == user.UserId);
        var hasEnrolments = await Db.Enrolments.AnyAsync(e => e.Participant.UserId == user.UserId);
        if (hasEvents || hasEnrolments)
            return Fail(StatusCodes.Status409Conflict, "Account cannot be deleted.",
                "Remove or cancel your events/enrolments first.");

        Db.Users.Remove(user);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Returns the Participant's personal performance history (all recorded results).</summary>
    /// <response code="200">Results, newest event first.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Only Participants have a performance history.</response>
    [HttpGet("api/users/me/history")]
    [Authorize(Roles = Roles.Participant)]
    [ProducesResponseType(typeof(List<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetHistory()
    {
        var results = await Db.Results
            .Where(r => r.Enrolment.Participant.UserId == CurrentUserId)
            .OrderByDescending(r => r.Enrolment.Category.Event.EventDate)
            .Select(Projections.ResultInfo)
            .ToListAsync();
        return Ok(results);
    }

    private Task<User?> LoadUser() =>
        Db.Users.Include(u => u.Organiser).Include(u => u.Participant)
            .FirstOrDefaultAsync(u => u.UserId == CurrentUserId);

    private static UserProfileResponse ToProfile(User u) => new()
    {
        UserId = u.UserId,
        Email = u.Email,
        FirstName = u.FirstName,
        LastName = u.LastName,
        Role = u.Role,
        CreatedAt = u.CreatedAt,
        OrganiserId = u.Organiser?.OrganiserId,
        OrganisationName = u.Organiser?.OrganisationName,
        ContactNumber = u.Organiser?.ContactNumber,
        Website = u.Organiser?.Website,
        ParticipantId = u.Participant?.ParticipantId,
        DateOfBirth = u.Participant?.DateOfBirth,
        Gender = u.Participant?.Gender,
        Province = u.Participant?.Province,
        ClubName = u.Participant?.ClubName,
        EmergencyContact = u.Participant?.EmergencyContact,
        EmergencyPhone = u.Participant?.EmergencyPhone
    };
}
