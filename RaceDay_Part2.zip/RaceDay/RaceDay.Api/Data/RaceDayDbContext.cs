using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

/// <summary>
/// EF Core (code-first) model. Table names, column names, keys, unique constraints,
/// defaults and check constraints are configured to match the Part 1 ERD and SQL script.
/// </summary>
public class RaceDayDbContext : DbContext
{
    public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Organiser> Organisers => Set<Organiser>();
    public DbSet<Participant> Participants => Set<Participant>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<RoutePoint> RoutePoints => Set<RoutePoint>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<Result> Results => Set<Result>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<User>(e =>
        {
            e.ToTable("Users", t => t.HasCheckConstraint("CK_Users_Role", "[Role] IN (N'Organiser', N'Participant')"));
            e.HasKey(x => x.UserId).HasName("PK_Users");
            e.Property(x => x.Email).HasMaxLength(150).IsRequired();
            e.Property(x => x.PasswordHash).HasMaxLength(255).IsRequired();
            e.Property(x => x.FirstName).HasMaxLength(80).IsRequired();
            e.Property(x => x.LastName).HasMaxLength(80).IsRequired();
            e.Property(x => x.Role).HasMaxLength(20).IsRequired();
            e.Property(x => x.CreatedAt).HasColumnType("datetime2(0)").HasDefaultValueSql("SYSUTCDATETIME()");
            e.HasIndex(x => x.Email).IsUnique().HasDatabaseName("UQ_Users_Email");
        });

        mb.Entity<Organiser>(e =>
        {
            e.ToTable("Organisers");
            e.HasKey(x => x.OrganiserId).HasName("PK_Organisers");
            e.Property(x => x.OrganisationName).HasMaxLength(150).IsRequired();
            e.Property(x => x.ContactNumber).HasMaxLength(20).IsRequired();
            e.Property(x => x.Website).HasMaxLength(200);
            e.HasIndex(x => x.UserId).IsUnique().HasDatabaseName("UQ_Organisers_UserId");
            e.HasOne(x => x.User).WithOne(u => u.Organiser)
                .HasForeignKey<Organiser>(x => x.UserId)
                .HasConstraintName("FK_Organisers_Users")
                .OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<Participant>(e =>
        {
            e.ToTable("Participants", t => t.HasCheckConstraint("CK_Participants_Gender", "[Gender] IN (N'Male', N'Female', N'Other')"));
            e.HasKey(x => x.ParticipantId).HasName("PK_Participants");
            e.Property(x => x.DateOfBirth).HasColumnType("date");
            e.Property(x => x.Gender).HasMaxLength(10).IsRequired();
            e.Property(x => x.Province).HasMaxLength(50);
            e.Property(x => x.ClubName).HasMaxLength(100);
            e.Property(x => x.EmergencyContact).HasMaxLength(100).IsRequired();
            e.Property(x => x.EmergencyPhone).HasMaxLength(20).IsRequired();
            e.HasIndex(x => x.UserId).IsUnique().HasDatabaseName("UQ_Participants_UserId");
            e.HasOne(x => x.User).WithOne(u => u.Participant)
                .HasForeignKey<Participant>(x => x.UserId)
                .HasConstraintName("FK_Participants_Users")
                .OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<Event>(e =>
        {
            e.ToTable("Events", t =>
            {
                t.HasCheckConstraint("CK_Events_Type", "[EventType] IN (N'Running', N'Walking', N'Cycling')");
                t.HasCheckConstraint("CK_Events_Status", "[Status] IN (N'Open', N'Closed', N'Completed', N'Cancelled')");
                t.HasCheckConstraint("CK_Events_Deadline", "[RegistrationDeadline] <= [EventDate]");
            });
            e.HasKey(x => x.EventId).HasName("PK_Events");
            e.Property(x => x.Name).HasMaxLength(150).IsRequired();
            e.Property(x => x.Description).HasMaxLength(1000);
            e.Property(x => x.EventType).HasMaxLength(20).IsRequired();
            e.Property(x => x.EventDate).HasColumnType("date");
            e.Property(x => x.StartTime).HasColumnType("time(0)");
            e.Property(x => x.Venue).HasMaxLength(150).IsRequired();
            e.Property(x => x.City).HasMaxLength(80).IsRequired();
            e.Property(x => x.Province).HasMaxLength(50).IsRequired();
            e.Property(x => x.Latitude).HasPrecision(9, 6);
            e.Property(x => x.Longitude).HasPrecision(9, 6);
            e.Property(x => x.RegistrationDeadline).HasColumnType("date");
            e.Property(x => x.Status).HasMaxLength(20).IsRequired().HasDefaultValue("Open");
            e.Property(x => x.CreatedAt).HasColumnType("datetime2(0)").HasDefaultValueSql("SYSUTCDATETIME()");
            e.HasOne(x => x.Organiser).WithMany(o => o.Events)
                .HasForeignKey(x => x.OrganiserId)
                .HasConstraintName("FK_Events_Organisers")
                .OnDelete(DeleteBehavior.Restrict);
        });

        mb.Entity<Category>(e =>
        {
            e.ToTable("Categories", t =>
            {
                t.HasCheckConstraint("CK_Categories_Distance", "[DistanceKm] > 0");
                t.HasCheckConstraint("CK_Categories_Fee", "[EntryFee] >= 0");
                t.HasCheckConstraint("CK_Categories_Max", "[MaxParticipants] > 0");
                t.HasCheckConstraint("CK_Categories_Age", "[MaxAge] IS NULL OR [MaxAge] >= [MinAge]");
            });
            e.HasKey(x => x.CategoryId).HasName("PK_Categories");
            e.Property(x => x.Name).HasMaxLength(80).IsRequired();
            e.Property(x => x.DistanceKm).HasPrecision(6, 2);
            e.Property(x => x.MinAge).HasDefaultValue(12);
            e.Property(x => x.EntryFee).HasPrecision(10, 2).HasDefaultValue(0m);
            e.HasIndex(x => new { x.EventId, x.Name }).IsUnique().HasDatabaseName("UQ_Categories_Event_Name");
            e.HasOne(x => x.Event).WithMany(ev => ev.Categories)
                .HasForeignKey(x => x.EventId)
                .HasConstraintName("FK_Categories_Events")
                .OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<RoutePoint>(e =>
        {
            e.ToTable("RoutePoints");
            e.HasKey(x => x.RoutePointId).HasName("PK_RoutePoints");
            e.Property(x => x.Label).HasMaxLength(100);
            e.Property(x => x.Latitude).HasPrecision(9, 6);
            e.Property(x => x.Longitude).HasPrecision(9, 6);
            e.HasIndex(x => new { x.EventId, x.SequenceNo }).IsUnique().HasDatabaseName("UQ_RoutePoints_Event_Seq");
            e.HasOne(x => x.Event).WithMany(ev => ev.RoutePoints)
                .HasForeignKey(x => x.EventId)
                .HasConstraintName("FK_RoutePoints_Events")
                .OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<Enrolment>(e =>
        {
            e.ToTable("Enrolments", t =>
            {
                t.HasCheckConstraint("CK_Enrolments_Pay", "[PaymentStatus] IN (N'Pending', N'Paid', N'Refunded')");
                t.HasCheckConstraint("CK_Enrolments_Status", "[Status] IN (N'Confirmed', N'Cancelled')");
            });
            e.HasKey(x => x.EnrolmentId).HasName("PK_Enrolments");
            e.Property(x => x.EnrolmentDate).HasColumnType("datetime2(0)").HasDefaultValueSql("SYSUTCDATETIME()");
            e.Property(x => x.PaymentStatus).HasMaxLength(20).IsRequired().HasDefaultValue("Pending");
            e.Property(x => x.Status).HasMaxLength(20).IsRequired().HasDefaultValue("Confirmed");
            e.HasIndex(x => new { x.ParticipantId, x.CategoryId }).IsUnique().HasDatabaseName("UQ_Enrolments_Participant_Category");
            e.HasOne(x => x.Participant).WithMany(p => p.Enrolments)
                .HasForeignKey(x => x.ParticipantId)
                .HasConstraintName("FK_Enrolments_Participants")
                .OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Category).WithMany(c => c.Enrolments)
                .HasForeignKey(x => x.CategoryId)
                .HasConstraintName("FK_Enrolments_Categories")
                .OnDelete(DeleteBehavior.Restrict);
        });

        mb.Entity<Result>(e =>
        {
            e.ToTable("Results", t =>
            {
                t.HasCheckConstraint("CK_Results_Status", "[ResultStatus] IN (N'Finished', N'DNF', N'DNS', N'DSQ')");
                t.HasCheckConstraint("CK_Results_Position", "[Position] IS NULL OR [Position] > 0");
            });
            e.HasKey(x => x.ResultId).HasName("PK_Results");
            e.Property(x => x.FinishTime).HasColumnType("time(2)");
            e.Property(x => x.ResultStatus).HasMaxLength(10).IsRequired().HasDefaultValue("Finished");
            e.Property(x => x.RecordedAt).HasColumnType("datetime2(0)").HasDefaultValueSql("SYSUTCDATETIME()");
            e.HasIndex(x => x.EnrolmentId).IsUnique().HasDatabaseName("UQ_Results_EnrolmentId");
            e.HasOne(x => x.Enrolment).WithOne(en => en.Result)
                .HasForeignKey<Result>(x => x.EnrolmentId)
                .HasConstraintName("FK_Results_Enrolments")
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
