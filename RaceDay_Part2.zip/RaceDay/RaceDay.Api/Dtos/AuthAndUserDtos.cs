using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Dtos;

/// <summary>Details needed to create an account. Organisers and Participants require different extra fields.</summary>
public class RegisterRequest
{
    [Required, EmailAddress, StringLength(150)]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(100, MinimumLength = 8)]
    public string Password { get; set; } = string.Empty;

    [Required, StringLength(80)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(80)]
    public string LastName { get; set; } = string.Empty;

    /// <summary>"Organiser" or "Participant".</summary>
    [Required]
    public string Role { get; set; } = string.Empty;

    // Organiser-only
    [StringLength(150)] public string? OrganisationName { get; set; }
    [StringLength(20)] public string? ContactNumber { get; set; }
    [StringLength(200)] public string? Website { get; set; }

    // Participant-only
    public DateOnly? DateOfBirth { get; set; }
    /// <summary>Male, Female or Other.</summary>
    public string? Gender { get; set; }
    [StringLength(50)] public string? Province { get; set; }
    [StringLength(100)] public string? ClubName { get; set; }
    [StringLength(100)] public string? EmergencyContact { get; set; }
    [StringLength(20)] public string? EmergencyPhone { get; set; }
}

public class RegisterResponse
{
    public int UserId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}

public class LoginRequest
{
    [Required, EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required]
    public string Password { get; set; } = string.Empty;
}

public class AuthResponse
{
    /// <summary>JWT bearer token. Send as "Authorization: Bearer {token}".</summary>
    public string Token { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public int UserId { get; set; }
    public DateTime ExpiresAt { get; set; }
}

public class UserProfileResponse
{
    public int UserId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }

    // Organiser
    public int? OrganiserId { get; set; }
    public string? OrganisationName { get; set; }
    public string? ContactNumber { get; set; }
    public string? Website { get; set; }

    // Participant
    public int? ParticipantId { get; set; }
    public DateOnly? DateOfBirth { get; set; }
    public string? Gender { get; set; }
    public string? Province { get; set; }
    public string? ClubName { get; set; }
    public string? EmergencyContact { get; set; }
    public string? EmergencyPhone { get; set; }
}

/// <summary>Fields a user may change on their own profile. Role-specific fields are ignored for the other role.</summary>
public class UpdateProfileRequest
{
    [Required, StringLength(80)] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(80)] public string LastName { get; set; } = string.Empty;

    [StringLength(150)] public string? OrganisationName { get; set; }
    [StringLength(20)] public string? ContactNumber { get; set; }
    [StringLength(200)] public string? Website { get; set; }

    public string? Gender { get; set; }
    [StringLength(50)] public string? Province { get; set; }
    [StringLength(100)] public string? ClubName { get; set; }
    [StringLength(100)] public string? EmergencyContact { get; set; }
    [StringLength(20)] public string? EmergencyPhone { get; set; }
}

public class ChangePasswordRequest
{
    [Required] public string CurrentPassword { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 8)] public string NewPassword { get; set; } = string.Empty;
}
