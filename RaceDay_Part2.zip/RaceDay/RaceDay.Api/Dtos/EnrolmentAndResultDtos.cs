using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Dtos;

public class EnrolmentResponse
{
    public int EnrolmentId { get; set; }
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateOnly EventDate { get; set; }
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int? RaceNumber { get; set; }
    public DateTime EnrolmentDate { get; set; }
    public string PaymentStatus { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
}

public class PaymentUpdateRequest
{
    /// <summary>Pending, Paid or Refunded.</summary>
    [Required, RegularExpression("^(Pending|Paid|Refunded)$", ErrorMessage = "PaymentStatus must be Pending, Paid or Refunded.")]
    public string PaymentStatus { get; set; } = string.Empty;
}

public class ResultRequest
{
    /// <summary>Finish time as hh:mm:ss (required when ResultStatus is Finished).</summary>
    public TimeSpan? FinishTime { get; set; }

    /// <summary>Finishing position within the category (1 = winner).</summary>
    [Range(1, 1000000)] public int? Position { get; set; }

    /// <summary>Finished, DNF, DNS or DSQ.</summary>
    [Required, RegularExpression("^(Finished|DNF|DNS|DSQ)$", ErrorMessage = "ResultStatus must be Finished, DNF, DNS or DSQ.")]
    public string ResultStatus { get; set; } = "Finished";
}

public class ResultResponse
{
    public int ResultId { get; set; }
    public int EnrolmentId { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateOnly EventDate { get; set; }
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int? RaceNumber { get; set; }
    public TimeSpan? FinishTime { get; set; }
    public int? Position { get; set; }
    public string ResultStatus { get; set; } = string.Empty;
}

public class CategoryResultsResponse
{
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public decimal DistanceKm { get; set; }
    public List<ResultResponse> Results { get; set; } = new();
}

public class EventResultsResponse
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public List<CategoryResultsResponse> Categories { get; set; } = new();
}
