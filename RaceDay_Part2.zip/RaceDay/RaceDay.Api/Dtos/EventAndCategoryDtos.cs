using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Dtos;

public class EventRequest
{
    [Required, StringLength(150)] public string Name { get; set; } = string.Empty;
    [StringLength(1000)] public string? Description { get; set; }

    /// <summary>Running, Walking or Cycling.</summary>
    [Required, RegularExpression("^(Running|Walking|Cycling)$", ErrorMessage = "EventType must be Running, Walking or Cycling.")]
    public string EventType { get; set; } = string.Empty;

    public DateOnly EventDate { get; set; }
    public TimeOnly StartTime { get; set; }

    [Required, StringLength(150)] public string Venue { get; set; } = string.Empty;
    [Required, StringLength(80)] public string City { get; set; } = string.Empty;
    [Required, StringLength(50)] public string Province { get; set; } = string.Empty;

    [Range(-90, 90)] public decimal Latitude { get; set; }
    [Range(-180, 180)] public decimal Longitude { get; set; }

    public DateOnly RegistrationDeadline { get; set; }

    /// <summary>Optional on update: Open, Closed, Completed or Cancelled.</summary>
    [RegularExpression("^(Open|Closed|Completed|Cancelled)$", ErrorMessage = "Status must be Open, Closed, Completed or Cancelled.")]
    public string? Status { get; set; }
}

public class EventSummaryResponse
{
    public int EventId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string EventType { get; set; } = string.Empty;
    public DateOnly EventDate { get; set; }
    public TimeOnly StartTime { get; set; }
    public string Venue { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Province { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public int OrganiserId { get; set; }
    public string OrganiserName { get; set; } = string.Empty;
    /// <summary>Distances (km) of the categories offered at this event.</summary>
    public List<decimal> DistancesKm { get; set; } = new();
}

public class EventDetailResponse : EventSummaryResponse
{
    public string? Description { get; set; }
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }
    public DateOnly RegistrationDeadline { get; set; }
    public List<CategoryResponse> Categories { get; set; } = new();
}

public class RoutePointDto
{
    [Range(1, 10000)] public int SequenceNo { get; set; }
    [StringLength(100)] public string? Label { get; set; }
    [Range(-90, 90)] public decimal Latitude { get; set; }
    [Range(-180, 180)] public decimal Longitude { get; set; }
}

public class RouteRequest
{
    [Required] public List<RoutePointDto> Points { get; set; } = new();
}

public class WeatherResponse
{
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }
    public double? TemperatureC { get; set; }
    public double? Humidity { get; set; }
    public double? WindSpeedKmh { get; set; }
    public string Conditions { get; set; } = string.Empty;
    /// <summary>Forecast for the event date (only available up to ~16 days ahead).</summary>
    public DayForecast? EventDayForecast { get; set; }
}

public class DayForecast
{
    public DateOnly Date { get; set; }
    public double? MinTempC { get; set; }
    public double? MaxTempC { get; set; }
    public double? PrecipitationChancePercent { get; set; }
    public string Conditions { get; set; } = string.Empty;
}

public class CategoryRequest
{
    /// <summary>e.g. "Under 20", "Senior", "10km", "21km".</summary>
    [Required, StringLength(80)] public string Name { get; set; } = string.Empty;
    [Range(0.01, 1000)] public decimal DistanceKm { get; set; }
    [Range(1, 120)] public int MinAge { get; set; } = 12;
    [Range(1, 120)] public int? MaxAge { get; set; }
    [Range(0, 100000)] public decimal EntryFee { get; set; }
    [Range(1, 1000000)] public int MaxParticipants { get; set; }
}

public class CategoryResponse
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal DistanceKm { get; set; }
    public int MinAge { get; set; }
    public int? MaxAge { get; set; }
    public decimal EntryFee { get; set; }
    public int MaxParticipants { get; set; }
    public int EnrolledCount { get; set; }
    public int SpotsRemaining { get; set; }
}
