namespace RaceDay.Api.Models;

public static class Roles
{
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";
}

public class User
{
    public int UserId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Organiser? Organiser { get; set; }
    public Participant? Participant { get; set; }
}

public class Organiser
{
    public int OrganiserId { get; set; }
    public int UserId { get; set; }
    public string OrganisationName { get; set; } = string.Empty;
    public string ContactNumber { get; set; } = string.Empty;
    public string? Website { get; set; }

    public User User { get; set; } = null!;
    public ICollection<Event> Events { get; set; } = new List<Event>();
}

public class Participant
{
    public int ParticipantId { get; set; }
    public int UserId { get; set; }
    public DateOnly DateOfBirth { get; set; }
    public string Gender { get; set; } = string.Empty;
    public string? Province { get; set; }
    public string? ClubName { get; set; }
    public string EmergencyContact { get; set; } = string.Empty;
    public string EmergencyPhone { get; set; } = string.Empty;

    public User User { get; set; } = null!;
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}

public class Event
{
    public int EventId { get; set; }
    public int OrganiserId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string EventType { get; set; } = string.Empty;   // Running | Walking | Cycling
    public DateOnly EventDate { get; set; }
    public TimeOnly StartTime { get; set; }
    public string Venue { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Province { get; set; } = string.Empty;
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }
    public DateOnly RegistrationDeadline { get; set; }
    public string Status { get; set; } = "Open";            // Open | Closed | Completed | Cancelled
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Organiser Organiser { get; set; } = null!;
    public ICollection<Category> Categories { get; set; } = new List<Category>();
    public ICollection<RoutePoint> RoutePoints { get; set; } = new List<RoutePoint>();
}

public class Category
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal DistanceKm { get; set; }
    public int MinAge { get; set; } = 12;
    public int? MaxAge { get; set; }
    public decimal EntryFee { get; set; }
    public int MaxParticipants { get; set; }

    public Event Event { get; set; } = null!;
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}

public class RoutePoint
{
    public int RoutePointId { get; set; }
    public int EventId { get; set; }
    public int SequenceNo { get; set; }
    public string? Label { get; set; }
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }

    public Event Event { get; set; } = null!;
}

public class Enrolment
{
    public int EnrolmentId { get; set; }
    public int ParticipantId { get; set; }
    public int CategoryId { get; set; }
    public int? RaceNumber { get; set; }
    public DateTime EnrolmentDate { get; set; } = DateTime.UtcNow;
    public string PaymentStatus { get; set; } = "Pending";  // Pending | Paid | Refunded
    public string Status { get; set; } = "Confirmed";       // Confirmed | Cancelled

    public Participant Participant { get; set; } = null!;
    public Category Category { get; set; } = null!;
    public Result? Result { get; set; }
}

public class Result
{
    public int ResultId { get; set; }
    public int EnrolmentId { get; set; }
    public TimeSpan? FinishTime { get; set; }
    public int? Position { get; set; }
    public string ResultStatus { get; set; } = "Finished";  // Finished | DNF | DNS | DSQ
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;

    public Enrolment Enrolment { get; set; } = null!;
}
