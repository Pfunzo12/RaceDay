using System.Linq.Expressions;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;

namespace RaceDay.Api.Services;

/// <summary>Reusable EF-translatable projections from entities to response DTOs.</summary>
public static class Projections
{
    public static readonly Expression<Func<Event, EventSummaryResponse>> EventSummary = e => new EventSummaryResponse
    {
        EventId = e.EventId,
        Name = e.Name,
        EventType = e.EventType,
        EventDate = e.EventDate,
        StartTime = e.StartTime,
        Venue = e.Venue,
        City = e.City,
        Province = e.Province,
        Status = e.Status,
        OrganiserId = e.OrganiserId,
        OrganiserName = e.Organiser.OrganisationName,
        DistancesKm = e.Categories.Select(c => c.DistanceKm).OrderBy(d => d).ToList()
    };

    public static readonly Expression<Func<Category, CategoryResponse>> CategoryInfo = c => new CategoryResponse
    {
        CategoryId = c.CategoryId,
        EventId = c.EventId,
        Name = c.Name,
        DistanceKm = c.DistanceKm,
        MinAge = c.MinAge,
        MaxAge = c.MaxAge,
        EntryFee = c.EntryFee,
        MaxParticipants = c.MaxParticipants,
        EnrolledCount = c.Enrolments.Count(x => x.Status == "Confirmed"),
        SpotsRemaining = c.MaxParticipants - c.Enrolments.Count(x => x.Status == "Confirmed")
    };

    public static readonly Expression<Func<Enrolment, EnrolmentResponse>> EnrolmentInfo = e => new EnrolmentResponse
    {
        EnrolmentId = e.EnrolmentId,
        ParticipantId = e.ParticipantId,
        ParticipantName = e.Participant.User.FirstName + " " + e.Participant.User.LastName,
        EventId = e.Category.EventId,
        EventName = e.Category.Event.Name,
        EventDate = e.Category.Event.EventDate,
        CategoryId = e.CategoryId,
        CategoryName = e.Category.Name,
        RaceNumber = e.RaceNumber,
        EnrolmentDate = e.EnrolmentDate,
        PaymentStatus = e.PaymentStatus,
        Status = e.Status
    };

    public static readonly Expression<Func<Result, ResultResponse>> ResultInfo = r => new ResultResponse
    {
        ResultId = r.ResultId,
        EnrolmentId = r.EnrolmentId,
        EventId = r.Enrolment.Category.EventId,
        EventName = r.Enrolment.Category.Event.Name,
        EventDate = r.Enrolment.Category.Event.EventDate,
        CategoryId = r.Enrolment.CategoryId,
        CategoryName = r.Enrolment.Category.Name,
        ParticipantId = r.Enrolment.ParticipantId,
        ParticipantName = r.Enrolment.Participant.User.FirstName + " " + r.Enrolment.Participant.User.LastName,
        RaceNumber = r.Enrolment.RaceNumber,
        FinishTime = r.FinishTime,
        Position = r.Position,
        ResultStatus = r.ResultStatus
    };
}
