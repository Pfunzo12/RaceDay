using System.Globalization;
using System.Text.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Api.Services;

public interface IWeatherService
{
    Task<WeatherResponse> GetWeatherAsync(decimal latitude, decimal longitude, DateOnly eventDate, CancellationToken ct);
}

/// <summary>Fetches live weather and a forecast from the free Open-Meteo API (no API key required).</summary>
public class WeatherService : IWeatherService
{
    private readonly HttpClient _http;

    public WeatherService(HttpClient http) => _http = http;

    public async Task<WeatherResponse> GetWeatherAsync(decimal latitude, decimal longitude, DateOnly eventDate, CancellationToken ct)
    {
        var lat = latitude.ToString(CultureInfo.InvariantCulture);
        var lon = longitude.ToString(CultureInfo.InvariantCulture);
        var url = $"v1/forecast?latitude={lat}&longitude={lon}" +
                  "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code" +
                  "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                  "&timezone=auto&forecast_days=16";

        using var response = await _http.GetAsync(url, ct);
        response.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
        var root = doc.RootElement;

        var current = root.GetProperty("current");
        var result = new WeatherResponse
        {
            Latitude = latitude,
            Longitude = longitude,
            TemperatureC = GetDouble(current, "temperature_2m"),
            Humidity = GetDouble(current, "relative_humidity_2m"),
            WindSpeedKmh = GetDouble(current, "wind_speed_10m"),
            Conditions = Describe((int?)GetDouble(current, "weather_code"))
        };

        var daily = root.GetProperty("daily");
        var times = daily.GetProperty("time").EnumerateArray().Select(t => t.GetString()).ToList();
        var index = times.IndexOf(eventDate.ToString("yyyy-MM-dd"));
        if (index >= 0)
        {
            result.EventDayForecast = new DayForecast
            {
                Date = eventDate,
                MinTempC = GetDoubleAt(daily, "temperature_2m_min", index),
                MaxTempC = GetDoubleAt(daily, "temperature_2m_max", index),
                PrecipitationChancePercent = GetDoubleAt(daily, "precipitation_probability_max", index),
                Conditions = Describe((int?)GetDoubleAt(daily, "weather_code", index))
            };
        }

        return result;
    }

    private static double? GetDouble(JsonElement obj, string name) =>
        obj.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.Number ? p.GetDouble() : null;

    private static double? GetDoubleAt(JsonElement obj, string name, int index)
    {
        if (!obj.TryGetProperty(name, out var arr) || arr.ValueKind != JsonValueKind.Array || index >= arr.GetArrayLength())
            return null;
        var item = arr[index];
        return item.ValueKind == JsonValueKind.Number ? item.GetDouble() : null;
    }

    /// <summary>Maps WMO weather codes to a readable description.</summary>
    private static string Describe(int? code) => code switch
    {
        0 => "Clear sky",
        1 or 2 => "Partly cloudy",
        3 => "Overcast",
        45 or 48 => "Fog",
        >= 51 and <= 57 => "Drizzle",
        >= 61 and <= 67 => "Rain",
        >= 71 and <= 77 => "Snow",
        >= 80 and <= 82 => "Rain showers",
        85 or 86 => "Snow showers",
        95 or 96 or 99 => "Thunderstorm",
        _ => "Unknown"
    };
}
