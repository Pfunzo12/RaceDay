using System.Net;
using System.Net.Http.Json;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

/// <summary>User registration and login: success and failure scenarios.</summary>
public class AuthenticationTests : ApiTestBase
{
    public AuthenticationTests(RaceDayFactory factory) : base(factory) { }

    [Fact]
    public async Task Register_Organiser_ReturnsCreated()
    {
        var response = await Anonymous().PostAsJsonAsync("/api/auth/register", OrganiserRegistration($"o_{Guid.NewGuid():N}@test.com"));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<RegisterResponse>();
        Assert.Equal("Organiser", body!.Role);
    }

    [Fact]
    public async Task Register_Participant_ReturnsCreated()
    {
        var response = await Anonymous().PostAsJsonAsync("/api/auth/register", ParticipantRegistration($"p_{Guid.NewGuid():N}@test.com"));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<RegisterResponse>();
        Assert.Equal("Participant", body!.Role);
    }

    [Fact]
    public async Task Register_StoresHashedPassword_NotPlainText()
    {
        var email = $"hash_{Guid.NewGuid():N}@test.com";
        await Anonymous().PostAsJsonAsync("/api/auth/register", ParticipantRegistration(email));

        using var scope = Factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<RaceDayDbContext>();
        var user = db.Users.Single(u => u.Email == email);

        Assert.NotEqual(Password, user.PasswordHash);
        Assert.StartsWith("$2", user.PasswordHash); // BCrypt hash
    }

    [Fact]
    public async Task Register_DuplicateEmail_ReturnsConflict()
    {
        var email = $"dup_{Guid.NewGuid():N}@test.com";
        var client = Anonymous();
        await client.PostAsJsonAsync("/api/auth/register", ParticipantRegistration(email));

        var second = await client.PostAsJsonAsync("/api/auth/register", ParticipantRegistration(email));

        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task Register_InvalidRole_ReturnsBadRequest()
    {
        var request = ParticipantRegistration($"r_{Guid.NewGuid():N}@test.com");
        request.Role = "Admin";

        var response = await Anonymous().PostAsJsonAsync("/api/auth/register", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_OrganiserWithoutOrganisationName_ReturnsBadRequest()
    {
        var request = OrganiserRegistration($"o_{Guid.NewGuid():N}@test.com");
        request.OrganisationName = null;

        var response = await Anonymous().PostAsJsonAsync("/api/auth/register", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_ParticipantWithoutEmergencyContact_ReturnsBadRequest()
    {
        var request = ParticipantRegistration($"p_{Guid.NewGuid():N}@test.com");
        request.EmergencyContact = null;

        var response = await Anonymous().PostAsJsonAsync("/api/auth/register", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_ShortPassword_ReturnsBadRequest()
    {
        var request = ParticipantRegistration($"p_{Guid.NewGuid():N}@test.com");
        request.Password = "short";

        var response = await Anonymous().PostAsJsonAsync("/api/auth/register", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Login_ValidCredentials_ReturnsTokenAndRole()
    {
        var email = $"login_{Guid.NewGuid():N}@test.com";
        var client = Anonymous();
        await client.PostAsJsonAsync("/api/auth/register", OrganiserRegistration(email));

        var response = await client.PostAsJsonAsync("/api/auth/login", new LoginRequest { Email = email, Password = Password });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var auth = await response.Content.ReadFromJsonAsync<AuthResponse>();
        Assert.False(string.IsNullOrWhiteSpace(auth!.Token));
        Assert.Equal("Organiser", auth.Role);
    }

    [Fact]
    public async Task Login_WrongPassword_ReturnsUnauthorized()
    {
        var email = $"wrong_{Guid.NewGuid():N}@test.com";
        var client = Anonymous();
        await client.PostAsJsonAsync("/api/auth/register", ParticipantRegistration(email));

        var response = await client.PostAsJsonAsync("/api/auth/login", new LoginRequest { Email = email, Password = "NotThePassword1" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Login_UnknownEmail_ReturnsUnauthorized()
    {
        var response = await Anonymous().PostAsJsonAsync("/api/auth/login",
            new LoginRequest { Email = "nobody@test.com", Password = Password });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task ProtectedEndpoint_WithValidToken_ReturnsProfile()
    {
        var user = await NewParticipantAsync();

        var response = await user.Client.GetAsync("/api/users/me");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var profile = await response.Content.ReadFromJsonAsync<UserProfileResponse>();
        Assert.Equal(user.Email, profile!.Email);
        Assert.Equal("Participant", profile.Role);
    }

    [Fact]
    public async Task ProtectedEndpoint_WithoutToken_ReturnsUnauthorized()
    {
        var response = await Anonymous().GetAsync("/api/users/me");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task ProtectedEndpoint_WithInvalidToken_ReturnsUnauthorized()
    {
        var client = Anonymous();
        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", "not.a.real.token");

        var response = await client.GetAsync("/api/users/me");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }
}
