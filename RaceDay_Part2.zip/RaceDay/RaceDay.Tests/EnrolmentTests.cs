using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

/// <summary>Participants enrol in events by category and the enrolment is recorded correctly.</summary>
public class EnrolmentTests : ApiTestBase
{
    public EnrolmentTests(RaceDayFactory factory) : base(factory) { }

    [Fact]
    public async Task Participant_CanEnrol_AndEnrolmentIsRecorded()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);

        var response = await participant.Client.PostAsync($"/api/categories/{category.CategoryId}/enrolments", null);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var enrolment = await response.Content.ReadFromJsonAsync<EnrolmentResponse>();
        Assert.Equal(ev.EventId, enrolment!.EventId);
        Assert.Equal(category.CategoryId, enrolment.CategoryId);
        Assert.Equal("Confirmed", enrolment.Status);
        Assert.Equal(1, enrolment.RaceNumber!.Value);
    }

    [Fact]
    public async Task Enrolment_AppearsInParticipantsOwnList()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);

        var response = await participant.Client.GetAsync("/api/enrolments/mine");
        var mine = await response.Content.ReadFromJsonAsync<List<EnrolmentResponse>>();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains(mine!, e => e.EnrolmentId == enrolment.EnrolmentId && e.CategoryId == category.CategoryId);
    }

    [Fact]
    public async Task Organiser_CanSeeEnrolmentsForTheirEvent()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);

        var response = await organiser.Client.GetAsync($"/api/events/{ev.EventId}/enrolments");
        var list = await response.Content.ReadFromJsonAsync<List<EnrolmentResponse>>();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Single(list!);
        Assert.Equal(enrolment.EnrolmentId, list![0].EnrolmentId);
    }

    [Fact]
    public async Task RaceNumbers_AreUniqueWithinAnEvent()
    {
        var organiser = await NewOrganiserAsync();
        var first = await NewParticipantAsync();
        var second = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);

        var a = await EnrolAsync(first, category.CategoryId);
        var b = await EnrolAsync(second, category.CategoryId);

        Assert.NotEqual(a.RaceNumber, b.RaceNumber);
    }

    [Fact]
    public async Task Enrol_SameEventTwice_ReturnsConflict()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var tenK = await CreateCategoryAsync(organiser, ev.EventId, "10km");
        var fiveK = await CreateCategoryAsync(organiser, ev.EventId, "5km");
        await EnrolAsync(participant, tenK.CategoryId);

        var again = await participant.Client.PostAsync($"/api/categories/{tenK.CategoryId}/enrolments", null);
        var otherCategory = await participant.Client.PostAsync($"/api/categories/{fiveK.CategoryId}/enrolments", null);

        Assert.Equal(HttpStatusCode.Conflict, again.StatusCode);
        Assert.Equal(HttpStatusCode.Conflict, otherCategory.StatusCode);
    }

    [Fact]
    public async Task Enrol_WhenCategoryIsFull_ReturnsConflict()
    {
        var organiser = await NewOrganiserAsync();
        var first = await NewParticipantAsync();
        var second = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId, max: 1);
        await EnrolAsync(first, category.CategoryId);

        var response = await second.Client.PostAsync($"/api/categories/{category.CategoryId}/enrolments", null);

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_BelowMinimumAge_ReturnsBadRequest()
    {
        var organiser = await NewOrganiserAsync();
        var child = await NewParticipantAsync(dob: Today.AddYears(-10));
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId, "Senior", minAge: 18);

        var response = await child.Client.PostAsync($"/api/categories/{category.CategoryId}/enrolments", null);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_AfterRegistrationDeadline_ReturnsBadRequest()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser, ValidEvent(date: Today.AddDays(10), deadline: Today.AddDays(-1)));
        var category = await CreateCategoryAsync(organiser, ev.EventId);

        var response = await participant.Client.PostAsync($"/api/categories/{category.CategoryId}/enrolments", null);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_InNonExistentCategory_ReturnsNotFound()
    {
        var participant = await NewParticipantAsync();

        var response = await participant.Client.PostAsync("/api/categories/999999/enrolments", null);

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CanCancelEnrolment_ThenReEnrol()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);

        var cancel = await participant.Client.DeleteAsync($"/api/enrolments/{enrolment.EnrolmentId}");
        var reEnrol = await participant.Client.PostAsync($"/api/categories/{category.CategoryId}/enrolments", null);

        Assert.Equal(HttpStatusCode.NoContent, cancel.StatusCode);
        Assert.Equal(HttpStatusCode.Created, reEnrol.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotCancelSomeoneElsesEnrolment()
    {
        var organiser = await NewOrganiserAsync();
        var owner = await NewParticipantAsync();
        var other = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(owner, category.CategoryId);

        var response = await other.Client.DeleteAsync($"/api/enrolments/{enrolment.EnrolmentId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanUpdatePaymentStatus()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);

        var response = await organiser.Client.PatchAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/payment",
            new PaymentUpdateRequest { PaymentStatus = "Paid" });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await response.Content.ReadFromJsonAsync<EnrolmentResponse>();
        Assert.Equal("Paid", updated!.PaymentStatus);
    }
}
