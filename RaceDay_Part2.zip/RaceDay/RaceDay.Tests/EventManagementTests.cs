using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

/// <summary>Organisers can create, update and delete events; everyone can browse them.</summary>
public class EventManagementTests : ApiTestBase
{
    public EventManagementTests(RaceDayFactory factory) : base(factory) { }

    [Fact]
    public async Task Organiser_CanCreateEvent()
    {
        var organiser = await NewOrganiserAsync();

        var response = await organiser.Client.PostAsJsonAsync("/api/events", ValidEvent());

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var created = await response.Content.ReadFromJsonAsync<EventDetailResponse>();
        Assert.Equal("Test Spring 10K", created!.Name);
        Assert.Equal("Running", created.EventType);
    }

    [Fact]
    public async Task Organiser_CreateEvent_WithDeadlineAfterEventDate_ReturnsBadRequest()
    {
        var organiser = await NewOrganiserAsync();
        var request = ValidEvent(date: Today.AddDays(10), deadline: Today.AddDays(15));

        var response = await organiser.Client.PostAsJsonAsync("/api/events", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CreateEvent_WithInvalidEventType_ReturnsBadRequest()
    {
        var organiser = await NewOrganiserAsync();
        var request = ValidEvent();
        request.EventType = "Swimming";

        var response = await organiser.Client.PostAsJsonAsync("/api/events", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanUpdateOwnEvent()
    {
        var organiser = await NewOrganiserAsync();
        var ev = await CreateEventAsync(organiser);
        var update = ValidEvent();
        update.Name = "Renamed Event";

        var response = await organiser.Client.PutAsJsonAsync($"/api/events/{ev.EventId}", update);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await response.Content.ReadFromJsonAsync<EventDetailResponse>();
        Assert.Equal("Renamed Event", updated!.Name);
    }

    [Fact]
    public async Task Organiser_CannotUpdateAnotherOrganisersEvent()
    {
        var owner = await NewOrganiserAsync();
        var other = await NewOrganiserAsync();
        var ev = await CreateEventAsync(owner);

        var response = await other.Client.PutAsJsonAsync($"/api/events/{ev.EventId}", ValidEvent());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanDeleteOwnEvent_ThenItIsGone()
    {
        var organiser = await NewOrganiserAsync();
        var ev = await CreateEventAsync(organiser);

        var delete = await organiser.Client.DeleteAsync($"/api/events/{ev.EventId}");
        var get = await Anonymous().GetAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.NoContent, delete.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, get.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotDeleteAnotherOrganisersEvent()
    {
        var owner = await NewOrganiserAsync();
        var other = await NewOrganiserAsync();
        var ev = await CreateEventAsync(owner);

        var response = await other.Client.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotDeleteEventWithEnrolments()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        await EnrolAsync(participant, category.CategoryId);

        var response = await organiser.Client.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task UpdateEvent_NotFound_ReturnsNotFound()
    {
        var organiser = await NewOrganiserAsync();

        var response = await organiser.Client.PutAsJsonAsync("/api/events/999999", ValidEvent());

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Anyone_CanBrowseEvents_WithoutLoggingIn()
    {
        var organiser = await NewOrganiserAsync();
        var ev = await CreateEventAsync(organiser);

        var list = await Anonymous().GetAsync("/api/events");
        var single = await Anonymous().GetAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.OK, list.StatusCode);
        Assert.Equal(HttpStatusCode.OK, single.StatusCode);
        var events = await list.Content.ReadFromJsonAsync<List<EventSummaryResponse>>();
        Assert.Contains(events!, e => e.EventId == ev.EventId);
    }

    [Fact]
    public async Task Organiser_MyEvents_OnlyReturnsOwnEvents()
    {
        var organiserA = await NewOrganiserAsync();
        var organiserB = await NewOrganiserAsync();
        var evA = await CreateEventAsync(organiserA);
        var evB = await CreateEventAsync(organiserB);

        var response = await organiserA.Client.GetAsync("/api/events/mine");
        var mine = await response.Content.ReadFromJsonAsync<List<EventSummaryResponse>>();

        Assert.Contains(mine!, e => e.EventId == evA.EventId);
        Assert.DoesNotContain(mine!, e => e.EventId == evB.EventId);
    }

    [Fact]
    public async Task Organiser_CanAddCategories_AndEveryoneCanViewThem()
    {
        var organiser = await NewOrganiserAsync();
        var ev = await CreateEventAsync(organiser);
        await CreateCategoryAsync(organiser, ev.EventId, "10km");
        await CreateCategoryAsync(organiser, ev.EventId, "Under 20", minAge: 12, maxAge: 19);

        var response = await Anonymous().GetAsync($"/api/events/{ev.EventId}/categories");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var categories = await response.Content.ReadFromJsonAsync<List<CategoryResponse>>();
        Assert.Equal(2, categories!.Count);
    }

    [Fact]
    public async Task Organiser_DuplicateCategoryName_ReturnsConflict()
    {
        var organiser = await NewOrganiserAsync();
        var ev = await CreateEventAsync(organiser);
        await CreateCategoryAsync(organiser, ev.EventId, "10km");

        var response = await organiser.Client.PostAsJsonAsync($"/api/events/{ev.EventId}/categories",
            new CategoryRequest { Name = "10km", DistanceKm = 10, MinAge = 12, EntryFee = 100, MaxParticipants = 50 });

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Weather_ForExistingEvent_ReturnsOk()
    {
        var organiser = await NewOrganiserAsync();
        var ev = await CreateEventAsync(organiser);

        var response = await Anonymous().GetAsync($"/api/events/{ev.EventId}/weather");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}
