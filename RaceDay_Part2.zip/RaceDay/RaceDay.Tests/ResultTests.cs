using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

/// <summary>Organisers capture results; Participants view their own.</summary>
public class ResultTests : ApiTestBase
{
    public ResultTests(RaceDayFactory factory) : base(factory) { }

    private static ResultRequest Finished(int position, int minutes) =>
        new() { Position = position, FinishTime = TimeSpan.FromMinutes(minutes), ResultStatus = "Finished" };

    [Fact]
    public async Task Organiser_CanCaptureResult_AndParticipantCanViewIt()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);
        await MakeEventPastAsync(ev.EventId);

        var create = await organiser.Client.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/result", Finished(1, 45));
        var mine = await participant.Client.GetAsync("/api/results/mine");
        var results = await mine.Content.ReadFromJsonAsync<List<ResultResponse>>();

        Assert.Equal(HttpStatusCode.Created, create.StatusCode);
        Assert.Single(results!);
        Assert.Equal(1, results![0].Position!.Value);
        Assert.Equal(TimeSpan.FromMinutes(45), results[0].FinishTime);
    }

    [Fact]
    public async Task Result_BeforeEventHasTakenPlace_ReturnsBadRequest()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser); // 30 days in the future
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);

        var response = await organiser.Client.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/result", Finished(1, 45));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Result_FinishedWithoutTime_ReturnsBadRequest()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);
        await MakeEventPastAsync(ev.EventId);

        var response = await organiser.Client.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/result",
            new ResultRequest { Position = 1, ResultStatus = "Finished" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Result_DuplicateForSameEnrolment_ReturnsConflict()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);
        await MakeEventPastAsync(ev.EventId);
        await organiser.Client.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/result", Finished(1, 45));

        var response = await organiser.Client.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/result", Finished(2, 46));

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Result_SamePositionInCategory_ReturnsConflict()
    {
        var organiser = await NewOrganiserAsync();
        var first = await NewParticipantAsync();
        var second = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var e1 = await EnrolAsync(first, category.CategoryId);
        var e2 = await EnrolAsync(second, category.CategoryId);
        await MakeEventPastAsync(ev.EventId);
        await organiser.Client.PostAsJsonAsync($"/api/enrolments/{e1.EnrolmentId}/result", Finished(1, 45));

        var response = await organiser.Client.PostAsJsonAsync($"/api/enrolments/{e2.EnrolmentId}/result", Finished(1, 47));

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotCaptureResultsForAnotherOrganisersEvent()
    {
        var owner = await NewOrganiserAsync();
        var other = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(owner);
        var category = await CreateCategoryAsync(owner, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);
        await MakeEventPastAsync(ev.EventId);

        var response = await other.Client.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/result", Finished(1, 45));

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_OnlySeesOwnResults()
    {
        var organiser = await NewOrganiserAsync();
        var runnerA = await NewParticipantAsync();
        var runnerB = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var eA = await EnrolAsync(runnerA, category.CategoryId);
        var eB = await EnrolAsync(runnerB, category.CategoryId);
        await MakeEventPastAsync(ev.EventId);
        await organiser.Client.PostAsJsonAsync($"/api/enrolments/{eA.EnrolmentId}/result", Finished(1, 40));
        await organiser.Client.PostAsJsonAsync($"/api/enrolments/{eB.EnrolmentId}/result", Finished(2, 42));

        var results = await (await runnerB.Client.GetAsync("/api/results/mine")).Content.ReadFromJsonAsync<List<ResultResponse>>();

        Assert.Single(results!);
        Assert.Equal(2, results![0].Position!.Value);
    }

    [Fact]
    public async Task PublicResults_AreOrderedByPosition()
    {
        var organiser = await NewOrganiserAsync();
        var first = await NewParticipantAsync();
        var second = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var e1 = await EnrolAsync(first, category.CategoryId);
        var e2 = await EnrolAsync(second, category.CategoryId);
        await MakeEventPastAsync(ev.EventId);
        await organiser.Client.PostAsJsonAsync($"/api/enrolments/{e1.EnrolmentId}/result", Finished(2, 50));
        await organiser.Client.PostAsJsonAsync($"/api/enrolments/{e2.EnrolmentId}/result", Finished(1, 45));

        var response = await Anonymous().GetAsync($"/api/events/{ev.EventId}/results");
        var body = await response.Content.ReadFromJsonAsync<EventResultsResponse>();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var results = body!.Categories.Single().Results;
        Assert.Equal(new int?[] { 1, 2 }, results.Select(r => r.Position).ToArray());
    }
}
