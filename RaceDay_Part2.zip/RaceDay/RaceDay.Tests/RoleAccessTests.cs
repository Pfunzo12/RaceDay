using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

/// <summary>Role-based access: unauthenticated users get 401, the wrong role gets 403.</summary>
public class RoleAccessTests : ApiTestBase
{
    public RoleAccessTests(RaceDayFactory factory) : base(factory) { }

    // ---------- Unauthenticated ----------

    [Theory]
    [InlineData("GET", "/api/users/me")]
    [InlineData("GET", "/api/users/me/history")]
    [InlineData("GET", "/api/events/mine")]
    [InlineData("GET", "/api/enrolments/mine")]
    [InlineData("GET", "/api/results/mine")]
    [InlineData("GET", "/api/events/1/enrolments")]
    public async Task Unauthenticated_ProtectedGet_ReturnsUnauthorized(string method, string url)
    {
        var response = await Anonymous().SendAsync(new HttpRequestMessage(new HttpMethod(method), url));

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Unauthenticated_CannotCreateEvent()
    {
        var response = await Anonymous().PostAsJsonAsync("/api/events", ValidEvent());

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Unauthenticated_CannotEnrol()
    {
        var response = await Anonymous().PostAsync("/api/categories/1/enrolments", null);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    // ---------- Participant calling Organiser endpoints ----------

    [Fact]
    public async Task Participant_CannotCreateEvent()
    {
        var participant = await NewParticipantAsync();

        var response = await participant.Client.PostAsJsonAsync("/api/events", ValidEvent());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotUpdateOrDeleteEvent()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);

        var put = await participant.Client.PutAsJsonAsync($"/api/events/{ev.EventId}", ValidEvent());
        var delete = await participant.Client.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Forbidden, put.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, delete.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotCreateCategory()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);

        var response = await participant.Client.PostAsJsonAsync($"/api/events/{ev.EventId}/categories",
            new CategoryRequest { Name = "Sneaky", DistanceKm = 5, MinAge = 12, EntryFee = 0, MaxParticipants = 10 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotViewEventEnrolmentList()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);

        var response = await participant.Client.GetAsync($"/api/events/{ev.EventId}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotCaptureResults()
    {
        var organiser = await NewOrganiserAsync();
        var participant = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(participant, category.CategoryId);

        var response = await participant.Client.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/result",
            new ResultRequest { FinishTime = TimeSpan.FromMinutes(40), Position = 1, ResultStatus = "Finished" });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    // ---------- Organiser calling Participant endpoints ----------

    [Fact]
    public async Task Organiser_CannotEnrol()
    {
        var organiser = await NewOrganiserAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);

        var response = await organiser.Client.PostAsync($"/api/categories/{category.CategoryId}/enrolments", null);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Theory]
    [InlineData("/api/users/me/history")]
    [InlineData("/api/enrolments/mine")]
    [InlineData("/api/results/mine")]
    public async Task Organiser_CannotCallParticipantOnlyEndpoints(string url)
    {
        var organiser = await NewOrganiserAsync();

        var response = await organiser.Client.GetAsync(url);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    // ---------- Ownership ----------

    [Fact]
    public async Task Organiser_CannotViewEnrolmentsOfAnotherOrganisersEvent()
    {
        var owner = await NewOrganiserAsync();
        var other = await NewOrganiserAsync();
        var ev = await CreateEventAsync(owner);

        var response = await other.Client.GetAsync($"/api/events/{ev.EventId}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotViewAnotherParticipantsEnrolment()
    {
        var organiser = await NewOrganiserAsync();
        var owner = await NewParticipantAsync();
        var stranger = await NewParticipantAsync();
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await EnrolAsync(owner, category.CategoryId);

        var response = await stranger.Client.GetAsync($"/api/enrolments/{enrolment.EnrolmentId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
