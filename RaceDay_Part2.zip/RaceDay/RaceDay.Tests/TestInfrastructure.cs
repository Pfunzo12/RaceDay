using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

/// <summary>Runs the real API in memory, swapping SQL Server for an isolated EF Core InMemory database.</summary>
public class RaceDayFactory : WebApplicationFactory<Program>
{
    private readonly string _dbName = "RaceDayTests-" + Guid.NewGuid();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.ConfigureServices(services =>
        {
            // Remove the SQL Server registrations added by Program.cs
            var toRemove = services.Where(d =>
                d.ServiceType == typeof(DbContextOptions<RaceDayDbContext>) ||
                d.ServiceType == typeof(DbContextOptions) ||
                (d.ServiceType.IsGenericType &&
                 d.ServiceType.Name.StartsWith("IDbContextOptionsConfiguration") &&
                 d.ServiceType.GenericTypeArguments[0] == typeof(RaceDayDbContext))).ToList();
            foreach (var d in toRemove) services.Remove(d);

            services.AddDbContext<RaceDayDbContext>(o => o.UseInMemoryDatabase(_dbName));

            // Never call the real weather service from tests
            services.AddScoped<IWeatherService, FakeWeatherService>();
        });
    }
}

public class FakeWeatherService : IWeatherService
{
    public Task<WeatherResponse> GetWeatherAsync(decimal latitude, decimal longitude, DateOnly eventDate, CancellationToken ct) =>
        Task.FromResult(new WeatherResponse { Latitude = latitude, Longitude = longitude, TemperatureC = 20, Conditions = "Clear sky" });
}

/// <summary>A logged-in test user: an HttpClient with the bearer token already attached.</summary>
public record TestUser(HttpClient Client, string Email, string Password, int UserId, string Role);

public abstract class ApiTestBase : IClassFixture<RaceDayFactory>
{
    protected const string Password = "Passw0rd!23";
    protected readonly RaceDayFactory Factory;

    protected ApiTestBase(RaceDayFactory factory) => Factory = factory;

    protected static DateOnly Today => DateOnly.FromDateTime(DateTime.UtcNow);
    protected HttpClient Anonymous() => Factory.CreateClient();

    protected static RegisterRequest OrganiserRegistration(string email) => new()
    {
        Email = email, Password = Password, FirstName = "Olive", LastName = "Organiser", Role = "Organiser",
        OrganisationName = "Test Runners Club", ContactNumber = "0821234567"
    };

    protected static RegisterRequest ParticipantRegistration(string email, DateOnly? dob = null) => new()
    {
        Email = email, Password = Password, FirstName = "Pat", LastName = "Participant", Role = "Participant",
        DateOfBirth = dob ?? new DateOnly(1990, 5, 20), Gender = "Female",
        EmergencyContact = "Sam Contact", EmergencyPhone = "0731112222"
    };

    private async Task<TestUser> RegisterAndLoginAsync(RegisterRequest registration)
    {
        var client = Factory.CreateClient();
        var reg = await client.PostAsJsonAsync("/api/auth/register", registration);
        reg.EnsureSuccessStatusCode();

        var login = await client.PostAsJsonAsync("/api/auth/login", new LoginRequest { Email = registration.Email, Password = registration.Password });
        login.EnsureSuccessStatusCode();
        var auth = (await login.Content.ReadFromJsonAsync<AuthResponse>())!;

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", auth.Token);
        return new TestUser(client, registration.Email, registration.Password, auth.UserId, auth.Role);
    }

    protected Task<TestUser> NewOrganiserAsync() => RegisterAndLoginAsync(OrganiserRegistration($"org_{Guid.NewGuid():N}@test.com"));

    protected Task<TestUser> NewParticipantAsync(DateOnly? dob = null) =>
        RegisterAndLoginAsync(ParticipantRegistration($"par_{Guid.NewGuid():N}@test.com", dob));

    protected static EventRequest ValidEvent(DateOnly? date = null, DateOnly? deadline = null) => new()
    {
        Name = "Test Spring 10K", Description = "A test event", EventType = "Running",
        EventDate = date ?? Today.AddDays(30), StartTime = new TimeOnly(6, 30),
        Venue = "Delta Park", City = "Johannesburg", Province = "Gauteng",
        Latitude = -26.1275m, Longitude = 28.0028m,
        RegistrationDeadline = deadline ?? Today.AddDays(20)
    };

    protected static async Task<EventDetailResponse> CreateEventAsync(TestUser organiser, EventRequest? request = null)
    {
        var response = await organiser.Client.PostAsJsonAsync("/api/events", request ?? ValidEvent());
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<EventDetailResponse>())!;
    }

    protected static async Task<CategoryResponse> CreateCategoryAsync(TestUser organiser, int eventId,
        string name = "10km", int minAge = 12, int? maxAge = null, int max = 100)
    {
        var response = await organiser.Client.PostAsJsonAsync($"/api/events/{eventId}/categories", new CategoryRequest
        {
            Name = name, DistanceKm = 10, MinAge = minAge, MaxAge = maxAge, EntryFee = 150, MaxParticipants = max
        });
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<CategoryResponse>())!;
    }

    protected static async Task<EnrolmentResponse> EnrolAsync(TestUser participant, int categoryId)
    {
        var response = await participant.Client.PostAsync($"/api/categories/{categoryId}/enrolments", null);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<EnrolmentResponse>())!;
    }

    /// <summary>Moves an event into the past so results can be captured.</summary>
    protected async Task MakeEventPastAsync(int eventId)
    {
        using var scope = Factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<RaceDayDbContext>();
        var ev = await db.Events.FindAsync(eventId);
        ev!.EventDate = Today.AddDays(-1);
        ev.RegistrationDeadline = Today.AddDays(-10);
        await db.SaveChangesAsync();
    }
}
